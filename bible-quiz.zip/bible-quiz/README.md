# Bible Quiz

A Pen created on CodePen.io. Original URL: [https://codepen.io/Matthew-Olushola-Oke/pen/LYKeNaL](https://codepen.io/Matthew-Olushola-Oke/pen/LYKeNaL).

