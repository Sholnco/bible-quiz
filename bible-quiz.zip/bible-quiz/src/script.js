// script.js
document.getElementById('run-btn').addEventListener('click', () => {
    const htmlCode = document.getElementById('html-editor').value;
    const jsCode = document.getElementById('js-editor').value;

    const iframe = document.getElementById('preview');
    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    iframeDoc.open();
    iframeDoc.write(htmlCode);
    iframeDoc.close();

    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.text = jsCode;
    iframeDoc.body.appendChild(script);
});
